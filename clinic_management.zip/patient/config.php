<?php
require_once '../vendor/autoload.php';
require_once "class-db.php";
 
define('CLIENT_ID', 'ynjjvsokQzWn1AHJBDlvAA');
define('CLIENT_SECRET', 'bls3gdBB7g8lNPzY2Ukx4AJiALpddVUN');
define('REDIRECT_URI', 'https://cb7e-102-117-42-13.ngrok-free.app/edoc-echanneling-main/patient/create-meeting.php');
define('STRIPE_PUBLIC_KEY', 'pk_test_51Q4LmKBhAeLMgReUuxeqbMHQahXye3yqxYup6y3crJLdjbgCehRiWOpElSH6iCmumHSqyZjoid3FJ0W7ynIEAXFZ00CRBUPVdx');
define('STRIPE_SECRET_KEY', 'sk_test_51Q4LmKBhAeLMgReUABf6aIY2ncoGS0xBLALuvy93bKRO6ZuSPaLeMI4P9mz3JGKAWIqJIwSDqM6JLylaQTMQE5Ra00SpTbEytI');